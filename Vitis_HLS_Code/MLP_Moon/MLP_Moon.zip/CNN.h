void CNN(float InModel[2],float &OutModel,float Weights[65]);
