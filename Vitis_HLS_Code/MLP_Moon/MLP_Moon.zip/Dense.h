void Dense_0(float input_Dense[2],float output_Dense[8],float bias[8],float weight[16]);
void Dense_1(float input_Dense[8],float output_Dense[4],float bias[4],float weight[32]);
void Dense_2(float input_Dense[4],float &output_Dense,float bias[1],float weight[4]);
